package com.dicoding.picodiploma.loginwithanimation.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.text.Editable
import android.text.TextWatcher
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatEditText
import androidx.core.content.ContextCompat
import com.dicoding.picodiploma.loginwithanimation.R

class MyEditTextEmail @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : AppCompatEditText(context, attrs){

    private var txtColor: Int = 0
    private var disabledBackground: Drawable
    private var enabledBackground: Drawable

    init {
        txtColor = ContextCompat.getColor(context, android.R.color.background_light)
        disabledBackground = ContextCompat.getDrawable(context, R.drawable.bg_edittext) as Drawable
        enabledBackground = ContextCompat.getDrawable(context, R.drawable.bg_edittext_disable) as Drawable

        addTextChangedListener(object : TextWatcher{
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (!android.util.Patterns.EMAIL_ADDRESS.matcher(s).matches()) {
                    setError("Email Tidak Valid!", null)
                } else if (android.util.Patterns.EMAIL_ADDRESS.matcher(s).matches()) {
                    error = null
                }
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        background = disabledBackground
    }
}