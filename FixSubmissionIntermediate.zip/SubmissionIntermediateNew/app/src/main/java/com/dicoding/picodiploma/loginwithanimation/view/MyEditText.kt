package com.dicoding.picodiploma.loginwithanimation.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.text.Editable
import android.text.TextWatcher
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatEditText
import androidx.core.content.ContextCompat
import com.dicoding.picodiploma.loginwithanimation.R

class MyEditText @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : AppCompatEditText(context, attrs){

    private var txtColor: Int = 0
    private var disabledBackground: Drawable
    private var enabledBackground: Drawable
    private var isError = false

    init {
        txtColor = ContextCompat.getColor(context, android.R.color.background_light)
        disabledBackground = ContextCompat.getDrawable(context, R.drawable.bg_edittext) as Drawable
        enabledBackground = ContextCompat.getDrawable(context, R.drawable.bg_edittext_disable) as Drawable

    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        background = disabledBackground

        addTextChangedListener(object : TextWatcher{
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (s.toString().length < 8) {
                    setError("Password tidak boleh kurang dari 8 karakter", null)
                    isError = true
                } else {
                    error = null
                    isError = false
                }
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
    }
}